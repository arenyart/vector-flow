import math

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty

from . import bridge
from .geom.fillet import fillet_path
from .geom.fit import simplify_path
from .geom.offset import offset_paths, outline_paths
from .geom.resample import resample_path
from .geom.cleanup import remove_doubles
from .geom.chisel import chisel_mesh

JOINS = [
    ("MITER", "Miter", "Sharp corners, falling back to bevel past the miter limit"),
    ("ROUND", "Round", "Rounded corners"),
    ("BEVEL", "Bevel", "Corners cut off flat"),
]
CAPS = [
    ("BUTT", "Butt", "Stroke stops exactly at the end points"),
    ("ROUND", "Round", "Semicircular ends"),
    ("SQUARE", "Projecting", "Square ends extending half the width past the end points"),
]


def _poll_curves(context):
    return any(bridge.is_curve(o) for o in context.selected_objects) or bridge.is_curve(context.active_object)


def _targets(context):
    objs = bridge.selected_curves(context)
    act = context.active_object
    if bridge.is_curve(act) and act not in objs:
        objs.append(act)
    return objs


def _select_results(context, objs):
    for o in context.selected_objects:
        o.select_set(False)
    for o in objs:
        o.select_set(True)
    context.view_layer.objects.active = objs[-1]


def _mark_modified(paths):
    for p in paths:
        p.meta = dict(p.meta)
        p.meta["modified"] = True
    return paths


class _ResultMixin:
    keep_original: BoolProperty(name="Keep Original", default=True,
                                description="Add the result as a new object and keep the source")
    precision: FloatProperty(name="Precision", default=5e-4, min=1e-5, max=2e-2, precision=5, step=0.001,
                             description="Approximation accuracy relative to the size of the shape")

    def _emit(self, context, src, result, z, suffix):
        if self.keep_original:
            obj = bridge.new_object_like(context, src, "%s.%s" % (src.name, suffix))
            bridge.write_paths(obj.data, result, z)
            return obj
        bridge.write_paths(src.data, result, z)
        return src


class CURVE_OT_illu_offset(_ResultMixin, bpy.types.Operator):
    """Offset Path: grow or shrink shapes by a fixed distance"""

    bl_idname = "curve.illu_offset"
    bl_label = "Offset Path"
    bl_options = {"REGISTER", "UNDO"}

    distance: FloatProperty(name="Offset", default=0.1, soft_min=-10, soft_max=10, subtype="DISTANCE",
                            unit="LENGTH", description="Positive grows the shape, negative shrinks it")
    join: EnumProperty(name="Joins", items=JOINS, default="MITER")
    miter_limit: FloatProperty(name="Miter Limit", default=4.0, min=1.0, max=100.0)

    @classmethod
    def poll(cls, context):
        return _poll_curves(context)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.prop(self, "distance")
        layout.prop(self, "join")
        if self.join == "MITER":
            layout.prop(self, "miter_limit")
        layout.prop(self, "keep_original")
        layout.prop(self, "precision")

    def execute(self, context):
        prev = bridge.ensure_object_mode(context)
        made = []
        for obj in _targets(context):
            paths, z, _ = bridge.read_paths(obj)
            if not paths:
                continue
            tol = bridge.tolerance(paths, self.precision)
            res = offset_paths(paths, self.distance, self.join, self.miter_limit, tol)
            if not res:
                self.report({"WARNING"}, "%s: offset collapsed the shape" % obj.name)
                continue
            made.append(self._emit(context, obj, res, z, "Offset"))
        bridge.restore_mode(prev)
        if not made:
            return {"CANCELLED"}
        _select_results(context, made)
        return {"FINISHED"}


class CURVE_OT_illu_outline_stroke(_ResultMixin, bpy.types.Operator):
    """Outline Stroke: turn paths into filled outlines of the given stroke width"""

    bl_idname = "curve.illu_outline_stroke"
    bl_label = "Outline Stroke"
    bl_options = {"REGISTER", "UNDO"}

    width: FloatProperty(name="Width", default=0.05, min=0.0, soft_max=5.0, subtype="DISTANCE", unit="LENGTH")
    join: EnumProperty(name="Joins", items=JOINS, default="ROUND")
    cap: EnumProperty(name="Caps", items=CAPS, default="BUTT")
    miter_limit: FloatProperty(name="Miter Limit", default=4.0, min=1.0, max=100.0)
    use_bevel_depth: BoolProperty(name="Use Curve Bevel", default=False,
                                  description="Use twice the curve's bevel depth as the width when it is set")

    @classmethod
    def poll(cls, context):
        return _poll_curves(context)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.prop(self, "use_bevel_depth")
        row = layout.row()
        row.active = not self.use_bevel_depth
        row.prop(self, "width")
        layout.prop(self, "join")
        if self.join == "MITER":
            layout.prop(self, "miter_limit")
        layout.prop(self, "cap")
        layout.prop(self, "keep_original")
        layout.prop(self, "precision")

    def execute(self, context):
        prev = bridge.ensure_object_mode(context)
        made = []
        for obj in _targets(context):
            paths, z, _ = bridge.read_paths(obj)
            if not paths:
                continue
            width = self.width
            if self.use_bevel_depth and obj.data.bevel_depth > 0:
                width = obj.data.bevel_depth * 2.0
            tol = bridge.tolerance(paths, self.precision)
            res = outline_paths(paths, width, self.join, self.cap, self.miter_limit, tol)
            if not res:
                continue
            out = self._emit(context, obj, res, z, "Outline")
            if out.data.bevel_depth and (self.use_bevel_depth or not self.keep_original):
                out.data.bevel_depth = 0.0
            out.data.dimensions = "2D"
            if out.data.fill_mode not in {"BOTH", "FRONT", "BACK"}:
                out.data.fill_mode = "BOTH"
            made.append(out)
        bridge.restore_mode(prev)
        if not made:
            self.report({"WARNING"}, "Nothing to outline")
            return {"CANCELLED"}
        _select_results(context, made)
        return {"FINISHED"}


class CURVE_OT_illu_fillet(bpy.types.Operator):
    """Round, chamfer or scoop corners. In Edit Mode only selected points are affected"""

    bl_idname = "curve.illu_fillet"
    bl_label = "Round Corners"
    bl_options = {"REGISTER", "UNDO"}

    radius: FloatProperty(name="Radius", default=0.1, min=0.0, soft_max=5.0, subtype="DISTANCE", unit="LENGTH")
    mode: EnumProperty(name="Corner", items=[
        ("ROUND", "Round", "Circular arc tangent to both sides"),
        ("INVERTED", "Inverted Round", "Concave arc centred on the corner"),
        ("CHAMFER", "Chamfer", "Straight cut"),
    ], default="ROUND")
    min_angle: FloatProperty(name="Corner Threshold", default=math.radians(5.0), min=0.0, max=math.radians(179.0),
                             subtype="ANGLE", description="Points that bend less than this are left alone")

    @classmethod
    def poll(cls, context):
        return _poll_curves(context) and context.mode in {"OBJECT", "EDIT_CURVE"}

    def execute(self, context):
        prev = bridge.ensure_object_mode(context)
        edit = prev == "EDIT_CURVE"
        objs = [context.active_object] if edit else _targets(context)
        total = 0
        for obj in objs:
            paths, z, _ = bridge.read_paths(obj)
            out = []
            changed = False
            for p in paths:
                if edit and not any(n.selected for n in p.nodes):
                    out.append(p)
                    continue
                q = fillet_path(p, self.radius, self.mode, selected_only=edit, min_angle=self.min_angle)
                if len(q.nodes) != len(p.nodes):
                    changed = True
                    total += len(q.nodes) - len(p.nodes)
                    _mark_modified([q])
                    out.append(q)
                else:
                    out.append(p)
            if changed:
                bridge.write_paths(obj.data, out, z)
        bridge.restore_mode(prev)
        if not total:
            self.report({"INFO"}, "No corners found" + (" among the selected points" if edit else ""))
        return {"FINISHED"}


class CURVE_OT_illu_simplify(bpy.types.Operator):
    """Simplify: refit paths with fewer points while keeping sharp corners. In Edit Mode only splines with selected points are affected"""

    bl_idname = "curve.illu_simplify"
    bl_label = "Simplify Path"
    bl_options = {"REGISTER", "UNDO"}

    tolerance: FloatProperty(name="Tolerance", default=2e-3, min=1e-5, max=0.1, precision=4, step=0.01,
                             description="Maximum deviation relative to the size of the shape")
    corner_angle: FloatProperty(name="Corner Angle", default=math.radians(40.0), min=math.radians(1.0),
                                max=math.radians(179.0), subtype="ANGLE",
                                description="Bends sharper than this stay as corners")

    @classmethod
    def poll(cls, context):
        return _poll_curves(context) and context.mode in {"OBJECT", "EDIT_CURVE"}

    def execute(self, context):
        prev = bridge.ensure_object_mode(context)
        edit = prev == "EDIT_CURVE"
        objs = [context.active_object] if edit else _targets(context)
        before = after = 0
        for obj in objs:
            paths, z, _ = bridge.read_paths(obj)
            err = bridge.tolerance(paths, self.tolerance)
            out = []
            for p in paths:
                if edit and not any(n.selected for n in p.nodes):
                    out.append(p)
                    continue
                q = simplify_path(p, err, self.corner_angle)
                before += len(p.nodes)
                after += len(q.nodes)
                out.append(_mark_modified([q])[0])
            bridge.write_paths(obj.data, out, z)
        bridge.restore_mode(prev)
        self.report({"INFO"}, "Simplify: %d → %d points" % (before, after))
        return {"FINISHED"}


class CURVE_OT_illu_resample(bpy.types.Operator):
    """Resample: redistribute points evenly along each path. In Edit Mode only splines with selected points are affected"""

    bl_idname = "curve.illu_resample"
    bl_label = "Resample Path"
    bl_options = {"REGISTER", "UNDO"}

    mode: EnumProperty(name="Mode", items=[
        ("COUNT", "Count", "Use this many points, spaced evenly by length"),
        ("LENGTH", "Length", "Place a point about every given distance"),
    ], default="COUNT")
    count: IntProperty(name="Points", default=16, min=2, max=10000,
                       description="Number of points on each path")
    spacing: FloatProperty(name="Spacing", default=0.1, min=1e-5, soft_max=10.0, subtype="DISTANCE",
                           unit="LENGTH", description="Target distance between points")
    smooth: BoolProperty(name="Smooth", default=True,
                         description="Fit a smooth curve through the new points. Off keeps straight segments")
    keep_corners: BoolProperty(name="Keep Corners", default=True,
                               description="Leave sharp corners where they are and resample the spans between them")
    corner_angle: FloatProperty(name="Corner Angle", default=math.radians(35.0), min=math.radians(1.0),
                                max=math.radians(179.0), subtype="ANGLE",
                                description="Bends sharper than this stay put")

    @classmethod
    def poll(cls, context):
        return _poll_curves(context) and context.mode in {"OBJECT", "EDIT_CURVE"}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.prop(self, "mode")
        if self.mode == "COUNT":
            layout.prop(self, "count")
        else:
            layout.prop(self, "spacing")
        layout.prop(self, "smooth")
        layout.prop(self, "keep_corners")
        if self.keep_corners:
            layout.prop(self, "corner_angle")

    def execute(self, context):
        prev = bridge.ensure_object_mode(context)
        edit = prev == "EDIT_CURVE"
        objs = [context.active_object] if edit else _targets(context)
        before = after = 0
        for obj in objs:
            paths, z, _ = bridge.read_paths(obj)
            out = []
            for p in paths:
                if edit and not any(n.selected for n in p.nodes):
                    out.append(p)
                    continue
                before += len(p.nodes)
                if self.mode == "COUNT":
                    q = resample_path(p, count=self.count, smooth=self.smooth,
                                      keep_corners=self.keep_corners, corner_angle=self.corner_angle)
                else:
                    q = resample_path(p, spacing=self.spacing, smooth=self.smooth,
                                      keep_corners=self.keep_corners, corner_angle=self.corner_angle)
                after += len(q.nodes)
                out.append(_mark_modified([q])[0])
            bridge.write_paths(obj.data, out, z)
        bridge.restore_mode(prev)
        self.report({"INFO"}, "Resample: %d → %d points" % (before, after))
        return {"FINISHED"}


class CURVE_OT_illu_remove_doubles(bpy.types.Operator):
    """Remove Doubles: weld neighboring points closer than the distance. In Edit Mode only selected points are merged"""

    bl_idname = "curve.illu_remove_doubles"
    bl_label = "Remove Doubles"
    bl_options = {"REGISTER", "UNDO"}

    distance: FloatProperty(name="Distance", default=0.0001, min=0.0, soft_max=1.0, subtype="DISTANCE",
                            unit="LENGTH", precision=5,
                            description="Neighboring points closer than this are welded")
    weld_ends: BoolProperty(name="Weld Ends", default=True,
                            description="Close an open path when its first and last points are within the distance")

    @classmethod
    def poll(cls, context):
        return _poll_curves(context) and context.mode in {"OBJECT", "EDIT_CURVE"}

    def execute(self, context):
        prev = bridge.ensure_object_mode(context)
        edit = prev == "EDIT_CURVE"
        objs = [context.active_object] if edit else _targets(context)
        before = after = 0
        for obj in objs:
            paths, z, _ = bridge.read_paths(obj)
            out = []
            for p in paths:
                if edit and not any(n.selected for n in p.nodes):
                    out.append(p)
                    continue
                before += len(p.nodes)
                q = remove_doubles(p, self.distance, selected_only=edit, weld_ends=self.weld_ends)
                after += len(q.nodes)
                if len(q.nodes) != len(p.nodes) or q.closed != p.closed:
                    _mark_modified([q])
                out.append(q)
            bridge.write_paths(obj.data, out, z)
        bridge.restore_mode(prev)
        removed = before - after
        self.report({"INFO"}, "Removed %d point%s" % (removed, "" if removed == 1 else "s"))
        return {"FINISHED"}


class CURVE_OT_illu_chisel(bpy.types.Operator):
    """Chisel: inset the shape, raise the inset, and loft the original edge up to it"""

    bl_idname = "curve.illu_chisel"
    bl_label = "Chisel"
    bl_options = {"REGISTER", "UNDO"}

    width: FloatProperty(name="Width", default=0.1, min=1e-5, soft_max=10.0, subtype="DISTANCE", unit="LENGTH",
                         description="How far the top face is inset from the outline")
    height: FloatProperty(name="Height", default=0.1, soft_min=-10.0, soft_max=10.0, subtype="DISTANCE",
                          unit="LENGTH", description="How far the inset face is raised. Negative sinks it")
    join: EnumProperty(name="Joins", items=JOINS, default="MITER")
    miter_limit: FloatProperty(name="Miter Limit", default=4.0, min=1.0, max=100.0)
    profile: EnumProperty(name="Profile", items=[
        ("LINEAR", "Linear", "Straight chamfer from the outline to the raised face"),
        ("CONVEX", "Convex", "Quarter-round bulge"),
        ("CONCAVE", "Concave", "Cove scooped into the edge"),
    ], default="LINEAR")
    divisions: IntProperty(name="Divisions", default=1, min=1, max=16,
                           description="Slices through the bevel. Use more with Convex or Concave")
    keep_original: BoolProperty(name="Keep Original", default=True)
    precision: FloatProperty(name="Precision", default=5e-4, min=1e-5, max=2e-2, precision=5, step=0.001,
                             description="Approximation accuracy relative to the size of the shape")

    @classmethod
    def poll(cls, context):
        return _poll_curves(context) and context.mode in {"OBJECT", "EDIT_CURVE"}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.prop(self, "width")
        layout.prop(self, "height")
        layout.prop(self, "profile")
        layout.prop(self, "divisions")
        layout.prop(self, "join")
        if self.join == "MITER":
            layout.prop(self, "miter_limit")
        layout.prop(self, "keep_original")
        layout.prop(self, "precision")

    def execute(self, context):
        prev = bridge.ensure_object_mode(context)
        made = []
        sources = []
        for obj in _targets(context):
            paths, z, planar = bridge.read_paths(obj)
            if not any(p.closed and len(p.nodes) >= 3 for p in paths):
                self.report({"WARNING"}, "%s has no closed shape to chisel" % obj.name)
                continue
            tol = bridge.tolerance(paths, self.precision)
            mesh = chisel_mesh(paths, self.width, self.height, tol, self.join, self.miter_limit,
                               self.divisions, self.profile)
            if mesh is None:
                self.report({"WARNING"}, "%s: the inset collapsed the shape" % obj.name)
                continue
            if not planar:
                self.report({"WARNING"}, "%s is not flat; it was projected onto its local XY plane" % obj.name)
            made.append(_add_chisel_mesh(context, obj, mesh[0], mesh[1], z))
            sources.append(obj)
        if sources and not self.keep_original:
            bridge.remove_objects(sources)
        bridge.restore_mode(prev)
        if not made:
            return {"CANCELLED"}
        _select_results(context, made)
        return {"FINISHED"}


def _add_chisel_mesh(context, src, verts, faces, z):
    mesh = bpy.data.meshes.new("%s.Chisel" % src.name)
    mesh.from_pydata([(v[0], v[1], v[2] + z) for v in verts], [], [list(f) for f in faces])
    mesh.update()
    if hasattr(mesh.polygons, "foreach_set"):
        try:
            mesh.polygons.foreach_set("use_smooth", [True] * len(mesh.polygons))
        except Exception:
            pass
    for mat in src.data.materials:
        if mat is not None:
            mesh.materials.append(mat)
    obj = bpy.data.objects.new("%s.Chisel" % src.name, mesh)
    obj.matrix_world = src.matrix_world.copy()
    for coll in src.users_collection or (context.collection,):
        coll.objects.link(obj)
    return obj


classes = (
    CURVE_OT_illu_offset,
    CURVE_OT_illu_outline_stroke,
    CURVE_OT_illu_fillet,
    CURVE_OT_illu_simplify,
    CURVE_OT_illu_resample,
    CURVE_OT_illu_remove_doubles,
    CURVE_OT_illu_chisel,
)
